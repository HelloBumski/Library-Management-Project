public class Loan {

    // book info
    String bookTitle;

    // member info
    String memberFullName;
    String idNum;

    // loan info
    int checkoutDate;
    int dueDate;


    public Loan(String bookTitle, String memberFullName, String idNum, int checkoutDate, int dueDate) {
        this.bookTitle = bookTitle;
        this.memberFullName = memberFullName;
        this.idNum = idNum;

        this.checkoutDate = checkoutDate;
        this.dueDate = dueDate;

    }
}
