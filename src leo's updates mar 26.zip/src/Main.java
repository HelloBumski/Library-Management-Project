// Simulation
public class Main {
    public static void main(String[] args) {

        Library lib = new Library(0, 19, 20, "Library", new String[]{"Hi", "bye"}, new String[]{"Geeked", "Goon"}, true);
        // make book and member objects

        while (true) {

            // Advance time
            lib.currentDay = lib.currentDay + 1;
            System.out.println("\n--- Day " + lib.currentDay + " ---");

            // simulate a random event
            int randomNumber = Rand.randomInt(0, 7); // could generate 0, 1, 2, or 3

            switch (randomNumber)
            {
                case 0:
                {
                    // someone returns a book
                    break;
                }

                case 1:
                {
                    // someone checks out a book
                    break;
                }

                case 2:
                {
                    // someone cancels subscription
                    break;
                }

                case 3:
                {
                    // someone signs up for a subscription

                }

                case 4:
                {
                    // someone has an overdue book
                    break;
                }

                case 5:
                {
                    System.out.println("Nothing happened");
                    break;
                }

            }

            Input.waitForUserToPressEnter("Press Enter to simulate the next day.");
        }
    }
}