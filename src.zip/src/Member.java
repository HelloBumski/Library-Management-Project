// Represents a member

public class Member
{
    public String fullName;
    public int age;
    public boolean hasCheckedOutBook;
    public boolean membershipActive;
    public int idNum;
    public int booksOwed;
    public int numBooksBorrowed;
    public Book[] listOfBorrowedBooks;



    public Member(String fullName, int age, boolean hasCheckedOutBook, boolean membershipActive, int idNum, int booksOwed, int numBooksBorrowed, Book[] listOfBorrowedBooks)
    {
        this.fullName = fullName;
        this.age = age;
        this.hasCheckedOutBook = hasCheckedOutBook;
        this.membershipActive = membershipActive;
        this.idNum = idNum;
        this.booksOwed = booksOwed;
        this.numBooksBorrowed = numBooksBorrowed;
        this.listOfBorrowedBooks = listOfBorrowedBooks;
    }
}
