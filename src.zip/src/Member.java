/*
 * Represents one library member.
 * Stores the member's name, membership status, and whether they currently have a book checked out.
 */
public class Member {
    public String fullName;
    public boolean hasCheckedOutBook;
    public boolean membershipActive;

    // Creates a member and sets name, membership status, and book check-out status
    public Member(String fullName, boolean hasCheckedOutBook, boolean membershipActive) {
        this.fullName = fullName;
        this.hasCheckedOutBook = hasCheckedOutBook;
        this.membershipActive = membershipActive;
    }
}
