/*
 * Represents one loan between a member and a book.
 * Stores the book, member, checkout date, and due date.
 */
public class Loan {
    Book book;        // The book that was borrowed
    Member member;    // The member who borrowed the book
    int checkoutDate; // The day the book was checked out
    int dueDate;      // The day the book is due back

    // Creates a loan and stores all the information
    public Loan(Book book, Member member, int checkoutDate, int dueDate) {
        this.book = book;
        this.member = member;
        this.checkoutDate = checkoutDate;
        this.dueDate = dueDate;
    }
}
