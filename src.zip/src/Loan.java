/*
 * Represents one loan between a member and a book.
 *
 * Fields:
 * - book (Book): the book that was borrowed
 * - member (Member): the member who borrowed the book
 * - checkoutDate (int): the day the book was checked out
 * - dueDate (int): the day the book is due back
 *
 * Constructor:
 * - Loan(Book book, Member member, int checkoutDate, int dueDate)
 * - Initializes all fields with the provided values
 * - Does not return anything
 */
public class Loan {
    public Book book;
    public Member member;
    public int checkoutDate;
    public int dueDate;

    public Loan(Book book, Member member, int checkoutDate, int dueDate) {
        this.book = book;
        this.member = member;
        this.checkoutDate = checkoutDate;
        this.dueDate = dueDate;
    }
}
