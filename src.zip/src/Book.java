/*
 * Represents a book in the library.
 *
 * Fields:
 * - authorName (String): the author of the book
 * - title (String): the title of the book
 * - isCheckedOut (boolean): true if the book is currently checked out
 *
 * Constructor:
 * - Book(String authorName, String title, boolean isCheckedOut)
 * - Initializes all fields with the provided values
 * - Does not return anything
 */
public class Book {
    public String authorName;
    public String title;
    public boolean isCheckedOut;

    public Book(String authorName, String title, boolean isCheckedOut) {
        this.authorName = authorName;
        this.title = title;
        this.isCheckedOut = isCheckedOut;
    }
}
