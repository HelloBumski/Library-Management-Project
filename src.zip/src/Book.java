/*
 * Represents a book in the library.
 * Stores the book's title, author, and whether it is checked out.
 */
public class Book {
    public String authorName;
    public String title;
    public boolean isCheckedOut;

    // Creates a book and sets its author, title, and checked-out status
    public Book(String authorName, String title, boolean isCheckedOut) {
        this.authorName = authorName;
        this.title = title;
        this.isCheckedOut = isCheckedOut;
    }
}
