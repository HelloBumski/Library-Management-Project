// Simulation
public class Main {
    public static void main(String[] args) {

        Book[] book = new Book[5]; // making an empty list of books with 5 spots

        book[0] = new Book("Jeff Kinney", "Diary of a Wimpy Kid", 2008, 6, 10, "Comedy", 210, false, 15);
        book[1] = new Book("Jeff Kinney", "Diary of a Wimpy Kid: Rodrick Rules", 2009, 6, 10, "Comedy", 225, false, 15);
        book[2] = new Book("Jeff Kinney", "Diary of a Wimpy Kid: The Last Straw", 2010, 6, 9, "Comedy", 220, false, 15);
        book[3] = new Book("Jeff Kinney", "Diary of a Wimpy Kid: Dog Days", 2011, 6, 14, "Comedy", 211, false, 15);
        book[4] = new Book("Jeff Kinney", "Diary of a Wimpy Kid: The Ugly Truth", 2012, 6, 23, "Comedy", 210, false, 15);


        Member[] member = new Member[5];

        member[0] = new Member("Dexter Morgan", 27, false, false, 64646464, 0, 0, new Book[]{null, null, null, null, null});
        member[1] = new Member("MF DOOM", 25, false, false, 65656565, 0, 0, new Book[]{null, null, null, null, null});
        member[2] = new Member("Slim Shady", 30, false, false, 66666666, 0, 0, new Book[]{null, null, null, null, null});
        member[3] = new Member("Kendrick Lamar", 31, false, false, 67676767, 0, 0, new Book[]{null, null, null, null, null});
        member[4] = new Member("Ant Saunders", 21, false, false, 68686868, 0, 0, new Book[]{null, null, null, null, null});


        Library lib = new Library(0, 19, 20, "Library", new Book[]{book[0], book[1], book[2], book[3], book[4]}, new Member[]{member[0], member[1], member[2], member[3], member[4]});

        // make book and member objects

        while (true) {

            // Advance time
            lib.currentDay = lib.currentDay + 1;
            System.out.println("\n--- Day " + lib.currentDay + " ---");

            // simulate a random event
            int randomNumber = Rand.randomInt(0, 8); // could generate 0-9

            switch (randomNumber)
            {
                case 0:
                {
                    // someone checks in a book
                    for (int i = 0; i < book.length; i++)
                    {
                        if (book[i].isCheckedOut)
                        {
                            System.out.println(member[i].fullName + " has returned " + book[i].title);
                            book[i].isCheckedOut = false;
                            break;
                        }
                    }
                }

                case 1:
                {
                    // someone checks out a book
                    for (int i = 0; i < book.length; i++)
                    {
                        System.out.println(book[i].title + " has been printed out by " + member[i].fullName);
                        book[i].isCheckedOut = true;
                        break;
                    }
                }

                case 2:
                {
                    // someone cancels subscription
                    for (Member m : member)
                    {
                        System.out.println(m.fullName + " has canceled their subscription to " + lib.nameOfLibrary);
                        m.membershipActive = false;
                        break;
                    }
                }

                case 3:
                {
                    // someone signs up for a subscription
                    for (Member m : member)
                    {
                        System.out.println(m.fullName + " has subscribed to " + lib.nameOfLibrary);
                        m.membershipActive = true;
                        break;
                    }
                }

                case 4:
                {
                    // someone has overdue books
                    break;
                }

                case 5:
                {
                    // nothing happens
                    break;
                }
            }

            Input.waitForUserToPressEnter("Press Enter to simulate the next day.");
        }
    }
}