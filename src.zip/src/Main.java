// Simulation
public class Main {
    public static void main(String[] args) {

        Library lib = new Library(0, 19, 20, "Library", new String[]{"Hi", "bye"}, new String[]{"Geeked", "Goon"}, true);
        // make book and member objects

        while (true) {

            // Advance time
            lib.currentDay = lib.currentDay + 1;
            System.out.println("\n--- Day " + lib.currentDay + " ---");

            // simulate a random event
            int randomNumber = Rand.randomInt(0, 10); // could generate 0, 1, 2, or 3

            switch (randomNumber)
            {
                case 0:
                {
                    // someone returns a book
                }

                case 1:
                {
                    // someone checks out a book
                }

                case 2:
                {
                    // someone cancels subscription
                }

                case 3:
                {
                    // someone signs up for a subscription
                }

                case 4:
                {
                    // someone takes out a loan
                }

                case 5:
                {
                    // someone returns a loan
                }

                case 6:
                {
                    // new book is added
                }

                case 7:
                {
                    // someone has overdue books
                }

                case 8:
                {
                    // someone has overdue loans
                }

                case 9:
                {
                    // nbook gets lost
                }

                case 10:
                {
                    // nothing happens
                }
            }

            Input.waitForUserToPressEnter("Press Enter to simulate the next day.");
        }
    }
}