/*
 * Main class that runs the library simulation.
 *
 * Fields (inside main method):
 * - books (Book[]): array holding all the books in the library
 * - members (Member[]): array holding all the members of the library
 * - loans (Loan[]): array holding the active loans (some slots may be empty)
 * - lib (Library): object representing the library and all its main data
 * - loanCount (int): number of active loans currently stored in the loans array
 *
 * Purpose:
 * - Initialize books, members, loans, and the library object
 * - Simulate the passage of days in the library
 * - Randomly perform one of several events each day:
 *     0: a member checks out a book
 *     1: a member returns a book
 *     2: a member cancels their subscription
 *     3: a member subscribes
 *     4: nothing happens
 * - Display the result of the day's event
 * - Wait for user input to proceed to the next day
 *
 * Returns:
 * - Nothing (void)
 * - cases 0-3 by Jurel
 * - cases 4-5 by Leo
 * - Object instantiation by Jurel and Leo
 */

public class Main {
    public static void main(String[] args) {

        // -------------------------
// Create the books in the library
// -------------------------
        Book[] books = new Book[5];

        books[0] = new Book("Jeff Kinney", "Diary of a Wimpy Kid", false);
        books[1] = new Book("Jeff Kinney", "Diary of a Wimpy Kid: Rodrick Rules", false);
        books[2] = new Book("Jeff Kinney", "Diary of a Wimpy Kid: The Last Straw", false);
        books[3] = new Book("Jeff Kinney", "Diary of a Wimpy Kid: Dog Days", false);
        books[4] = new Book("Jeff Kinney", "Diary of a Wimpy Kid: The Ugly Truth", false);

// -------------------------
// Create the members in the library
// -------------------------
        Member[] members = new Member[5];

        members[0] = new Member("Dexter Morgan", false, false);
        members[1] = new Member("MF DOOM", false, false);
        members[2] = new Member("Slim Shady", false, false);
        members[3] = new Member("Kendrick Lamar", false, false);
        members[4] = new Member("Ant Saunders", false, false);

// -------------------------
// Create the loan list
// -------------------------
        Loan[] loans = new Loan[5]; // Needed because the array size is fixed but not all slots may be used

// -------------------------
// Create the library object that holds all the main data
// -------------------------
        Library lib = new Library(0, "The Library", books, members, loans);


        // Keeps track of how many loans are currently being used.
        int loanCount = 0;


        // Run the simulation one day at a time.
        while (true)
        {
            // Move the simulation forward by one day.
            lib.currentDay = lib.currentDay + 1;
            System.out.println("\n--- Day " + lib.currentDay + " ---");


            // Pick a random event.
            int randomNumber = Rand.randomInt(0, 5);


            switch (randomNumber) {
                case 0: // A member checks out a book
                {
                    boolean checkoutHappened = false; // local variable to track action
                    for (Book b : lib.listOfBooks) {
                        if (!b.isCheckedOut) {
                            for (Member m : lib.listOfMembers) {
                                if (m.membershipActive && !m.hasCheckedOutBook) {
                                    System.out.println(m.fullName + " has checked out " + b.title);
                                    b.isCheckedOut = true;
                                    m.hasCheckedOutBook = true;
                                    lib.listOfLoans[loanCount] = new Loan(b, m, lib.currentDay, lib.currentDay + 7);
                                    loanCount++;
                                    checkoutHappened = true;
                                    break; // stops checking more members once one checkout is done
                                }
                            }
                            break; // stops checking more books once one checkout is done
                        }
                    }
                    if (!checkoutHappened) {
                        System.out.println("No checkout happened today.");
                    }
                    break; // stops the switch so no other case runs
                }

                case 1: // A member returns a book
                {
                    boolean returnHappened = false;
                    for (Book b : lib.listOfBooks) {
                        if (b.isCheckedOut) {
                            for (Member m : lib.listOfMembers) {
                                if (m.hasCheckedOutBook) {
                                    System.out.println(m.fullName + " has returned " + b.title);
                                    b.isCheckedOut = false;
                                    m.hasCheckedOutBook = false;
                                    for (int i = 0; i < loanCount; i++) {
                                        if (lib.listOfLoans[i].book == b && lib.listOfLoans[i].member == m) {
                                            lib.listOfLoans[i] = lib.listOfLoans[loanCount - 1];
                                            lib.listOfLoans[loanCount - 1] = null;
                                            loanCount--;
                                            break; // stops searching loans once the matching one is removed
                                        }
                                    }
                                    returnHappened = true;
                                    break; // stops checking more members once the return is done
                                }
                            }
                            break; // stops checking more books once a return is done
                        }
                    }
                    if (!returnHappened) {
                        System.out.println("No returns happened today.");
                    }
                    break; // stops the switch so no other case runs
                }

                case 2: // A member cancels subscription
                {
                    boolean cancelHappened = false;
                    for (Member m : lib.listOfMembers) {
                        if (m.membershipActive) {
                            System.out.println(m.fullName + " has canceled their subscription to " + lib.nameOfLibrary);
                            m.membershipActive = false;
                            cancelHappened = true;
                            break; // stops checking other members once one cancellation is done
                        }
                    }
                    if (!cancelHappened) {
                        System.out.println("No subscriptions canceled today.");
                    }
                    break; // stops the switch so no other case runs
                }

                case 3: // A member subscribes to the library
                {
                    boolean subscribeHappened = false;
                    for (Member m : lib.listOfMembers) {
                        if (!m.membershipActive) {
                            System.out.println(m.fullName + " has subscribed to " + lib.nameOfLibrary);
                            m.membershipActive = true;
                            subscribeHappened = true;
                            break; // stops checking other members once one subscription is done
                        }
                    }
                    if (!subscribeHappened) {
                        System.out.println("No new subscriptions today.");
                    }
                    break; // stops the switch so no other case runs
                }

                case 4: // Nothing happens
                {
                    System.out.println("Nothing happened today.");
                    break; // stops the switch so no other case runs
                }
            }




            // Wait until the user is ready to continue to the next day.
            Input.waitForUserToPressEnter("Press Enter to simulate the next day.");
        }
    }
}
