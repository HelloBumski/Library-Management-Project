/*
 * Represents the whole library system.
 * Stores the books, members, loans, and current day.
 */
public class Library {
    int currentDay;
    String nameOfLibrary;
    Book[] listOfBooks;
    Member[] listOfMembers;
    Loan[] listOfLoans;

    // Creates the library and stores the arrays and main values it needs
    public Library(int currentDay, String nameOfLibrary,
                   Book[] listOfBooks, Member[] listOfMembers, Loan[] listOfLoans) {
        this.currentDay = currentDay;
        this.nameOfLibrary = nameOfLibrary;
        this.listOfBooks = listOfBooks;
        this.listOfMembers = listOfMembers;
        this.listOfLoans = listOfLoans;
    }
}
