/*
 * Represents the whole library system.
 *
 * Fields:
 * - currentDay (int): current day of the simulation
 * - nameOfLibrary (String): name of the library
 * - listOfBooks (Book[]): array of all books in the library
 * - listOfMembers (Member[]): array of all members
 * - listOfLoans (Loan[]): array of active loans
 *
 * Constructor:
 * - Library(int currentDay, String nameOfLibrary, Book[] listOfBooks, Member[] listOfMembers, Loan[] listOfLoans)
 * - Initializes all fields with the provided values
 * - Does not return anything
 */
public class Library {
    public int currentDay;
    public String nameOfLibrary;
    public Book[] listOfBooks;
    public Member[] listOfMembers;
    public Loan[] listOfLoans;

    public Library(int currentDay, String nameOfLibrary, Book[] listOfBooks, Member[] listOfMembers, Loan[] listOfLoans) {
        this.currentDay = currentDay;
        this.nameOfLibrary = nameOfLibrary;
        this.listOfBooks = listOfBooks;
        this.listOfMembers = listOfMembers;
        this.listOfLoans = listOfLoans;
    }
}
