//Represents the entire library system
class Library {

    int currentDay; // Current simulation day
    int numBooks;
    int numMembers;
    String nameOfLibrary;
    Book[] listOfBooks;
    Member[] listOfMembers;




    public Library(int currentDay, int numBooks, int numMembers, String nameOfLibrary, Book[] listOfBooks, Member[] listOfMembers)
    {
        this.currentDay = currentDay;
        this.numBooks = numBooks;
        this.numMembers = numMembers;
        this.nameOfLibrary = nameOfLibrary;
        this.listOfBooks = listOfBooks;
        this.listOfMembers = listOfMembers;
    }
}