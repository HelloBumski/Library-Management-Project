/*
 * Represents one library member.
 *
 * Fields:
 * - fullName (String): member's full name
 * - hasCheckedOutBook (boolean): true if member currently has a book
 * - membershipActive (boolean): true if the subscription is active
 *
 * Constructor:
 * - Member(String fullName, boolean hasCheckedOutBook, boolean membershipActive)
 * - Initializes all fields with the provided values
 * - Does not return anything
 * - Jurel
 */
public class Member {
    private String fullName;
    private boolean hasCheckedOutBook;
    private boolean membershipActive;

    public Member(String fullName, boolean hasCheckedOutBook, boolean membershipActive) {
        this.fullName = fullName;
        this.hasCheckedOutBook = hasCheckedOutBook;
        this.membershipActive = membershipActive;
    }

    public String getFullName() {
        return fullName;
    }

    public boolean getHasCheckedOutBook() {
        return hasCheckedOutBook;
    }

    public boolean getMembershipActive() {
        return membershipActive;
    }

    public void setHasCheckedOutBook(boolean hasCheckedOutBook) {
        this.hasCheckedOutBook = hasCheckedOutBook;
    }

    public void setMembershipActive(boolean membershipActive) {
        this.membershipActive = membershipActive;
    }
}
