/*
 * Represents the whole library system.
 *
 * Fields:
 * - currentDay (int): current day of the simulation
 * - nameOfLibrary (String): name of the library
 * - listOfBooks (Book[]): array of all books in the library
 * - listOfMembers (Member[]): array of all members
 * - listOfLoans (Loan[]): array of active loans
 * - loanCount (int): number of active loans currently stored in the loans array
 *
 * Constructor:
 * - Library(int currentDay, String nameOfLibrary, Book[] listOfBooks, Member[] listOfMembers, Loan[] listOfLoans)
 * - Initializes all fields with the provided values
 * - Does not return anything
 * - Leo
 */
public class Library {
    private int currentDay;
    private String nameOfLibrary;
    private Book[] listOfBooks;
    private Member[] listOfMembers;
    private Loan[] listOfLoans;
    private int loanCount;

    public Library(int currentDay, String nameOfLibrary, Book[] listOfBooks, Member[] listOfMembers, Loan[] listOfLoans) {
        this.currentDay = currentDay;
        this.nameOfLibrary = nameOfLibrary;
        this.listOfBooks = listOfBooks;
        this.listOfMembers = listOfMembers;
        this.listOfLoans = listOfLoans;
        this.loanCount = 0;
    }

    public int getCurrentDay() {
        return currentDay;
    }

    public void setCurrentDay(int currentDay) {
        this.currentDay = currentDay;
    }

    public String getNameOfLibrary() {
        return nameOfLibrary;
    }

    public Book[] getListOfBooks() {
        return listOfBooks;
    }

    public Member[] getListOfMembers() {
        return listOfMembers;
    }

    public Loan[] getListOfLoans() {
        return listOfLoans;
    }

    public int getLoanCount() {
        return loanCount;
    }

    public void setLoanCount(int loanCount) {
        this.loanCount = loanCount;
    }
}
