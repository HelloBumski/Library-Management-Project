/*
 * Main class that runs the library simulation.
 *
 * Fields (inside main method):
 * - books (Book[]): array holding all the books in the library
 * - members (Member[]): array holding all the members of the library
 * - loans (Loan[]): array holding the active loans (some slots may be empty)
 * - lib (Library): object representing the library and all its main data
 *
 * Purpose:
 * - Initialize books, members, loans, and the library object
 * - Simulate the passage of days in the library
 * - Randomly perform one of several events each day:
 *     0: a member checks out a book
 *     1: a member returns a book
 *     2: a member cancels their subscription
 *     3: a member subscribes
 *     4: nothing happens
 * - Display the result of the day's event
 * - Wait for user input to proceed to the next day
 *
 * Returns:
 * - Nothing (void)
 * - cases 0-3 by Jurel
 * - cases 4-5 by Leo
 * - Object instantiation by Jurel and Leo
 */
public class Main {
    public static void main(String[] args) {

        // Create the books in the library.
        Book[] books = new Book[5];

        books[0] = new Book("Jeff Kinney", "Diary of a Wimpy Kid", false);
        books[1] = new Book("Jeff Kinney", "Diary of a Wimpy Kid: Rodrick Rules", false);
        books[2] = new Book("Jeff Kinney", "Diary of a Wimpy Kid: The Last Straw", false);
        books[3] = new Book("Jeff Kinney", "Diary of a Wimpy Kid: Dog Days", false);
        books[4] = new Book("Jeff Kinney", "Diary of a Wimpy Kid: The Ugly Truth", false);

        // Create the members in the library.
        Member[] members = new Member[5];

        members[0] = new Member("Dexter Morgan", false, false);
        members[1] = new Member("MF DOOM", false, false);
        members[2] = new Member("Slim Shady", false, false);
        members[3] = new Member("Kendrick Lamar", false, false);
        members[4] = new Member("Ant Saunders", false, false);

        // Create the loan list.
        Loan[] loans = new Loan[5];

        // Create the library object that holds all the main data.
        Library lib = new Library(0, "The Library", books, members, loans);

        // Run the simulation one day at a time.
        while (true)
        {
            lib.setCurrentDay(lib.getCurrentDay() + 1);
            System.out.println("\n--- Day " + lib.getCurrentDay() + " ---");

            int randomNumber = Rand.randomInt(0, 5);

            switch (randomNumber)
            {
                case 0:
                {
                    boolean checkoutHappened = false;

                    for (Book b : lib.getListOfBooks())
                    {
                        if (!b.getIsCheckedOut())
                        {
                            for (Member m : lib.getListOfMembers())
                            {
                                if (m.getMembershipActive() && !m.getHasCheckedOutBook())
                                {
                                    System.out.println(m.getFullName() + " has checked out " + b.getTitle());

                                    b.setIsCheckedOut(true);
                                    m.setHasCheckedOutBook(true);

                                    lib.getListOfLoans()[lib.getLoanCount()] = new Loan(b, m, lib.getCurrentDay(), lib.getCurrentDay() + 7);
                                    lib.setLoanCount(lib.getLoanCount() + 1);

                                    checkoutHappened = true;
                                    break;
                                }
                            }
                            break;
                        }
                    }

                    if (!checkoutHappened)
                    {
                        System.out.println("No checkout happened today.");
                    }

                    break;
                }

                case 1:
                {
                    boolean returnHappened = false;

                    for (Book b : lib.getListOfBooks())
                    {
                        if (b.getIsCheckedOut())
                        {
                            for (Member m : lib.getListOfMembers())
                            {
                                if (m.getHasCheckedOutBook())
                                {
                                    System.out.println(m.getFullName() + " has returned " + b.getTitle());

                                    b.setIsCheckedOut(false);
                                    m.setHasCheckedOutBook(false);

                                    for (int i = 0; i < lib.getLoanCount(); i++)
                                    {
                                        if (lib.getListOfLoans()[i].getBook() == b && lib.getListOfLoans()[i].getMember() == m)
                                        {
                                            lib.getListOfLoans()[i] = lib.getListOfLoans()[lib.getLoanCount() - 1];
                                            lib.getListOfLoans()[lib.getLoanCount() - 1] = null;
                                            lib.setLoanCount(lib.getLoanCount() - 1);
                                            break;
                                        }
                                    }

                                    returnHappened = true;
                                    break;
                                }
                            }
                            break;
                        }
                    }

                    if (!returnHappened)
                    {
                        System.out.println("No returns happened today.");
                    }

                    break;
                }

                case 2:
                {
                    boolean cancelHappened = false;

                    for (Member m : lib.getListOfMembers())
                    {
                        if (m.getMembershipActive())
                        {
                            System.out.println(m.getFullName() + " has canceled their subscription to " + lib.getNameOfLibrary());
                            m.setMembershipActive(false);
                            cancelHappened = true;
                            break;
                        }
                    }

                    if (!cancelHappened)
                    {
                        System.out.println("No subscriptions canceled today.");
                    }

                    break;
                }

                case 3:
                {
                    boolean subscribeHappened = false;

                    for (Member m : lib.getListOfMembers())
                    {
                        if (!m.getMembershipActive())
                        {
                            System.out.println(m.getFullName() + " has subscribed to " + lib.getNameOfLibrary());
                            m.setMembershipActive(true);
                            subscribeHappened = true;
                            break;
                        }
                    }

                    if (!subscribeHappened)
                    {
                        System.out.println("No new subscriptions today.");
                    }

                    break;
                }

                case 4:
                {
                    System.out.println("Nothing happened today.");
                    break;
                }
            }

            // After the random event finishes, loop through all active loans and check if any book is past its due date.
            for (int i = 0; i < lib.getLoanCount(); i++)
            {
                if (lib.getListOfLoans()[i].getDueDate() < lib.getCurrentDay())
                {
                    System.out.println(lib.getListOfLoans()[i].getMember().getFullName() + " needs to return " + lib.getListOfLoans()[i].getBook().getTitle() + " right away.");
                }
            }

            // Wait until the user is ready to continue to the next day.
            Input.waitForUserToPressEnter("Press Enter to simulate the next day.");
        }
    }
}
