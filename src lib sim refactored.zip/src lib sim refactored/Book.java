/*
 * Represents a book in the library.
 *
 * Fields:
 * - authorName (String): the author of the book
 * - title (String): the title of the book
 * - isCheckedOut (boolean): true if the book is currently checked out
 *
 * Constructor:
 * - Book(String authorName, String title, boolean isCheckedOut)
 * - Initializes all fields with the provided values
 * - Does not return anything
 * - Jurel
 */
public class Book {
    private String authorName;
    private String title;
    private boolean isCheckedOut;

    public Book(String authorName, String title, boolean isCheckedOut) {
        this.authorName = authorName;
        this.title = title;
        this.isCheckedOut = isCheckedOut;
    }

    public String getAuthorName() {
        return authorName;
    }

    public String getTitle() {
        return title;
    }

    public boolean getIsCheckedOut() {
        return isCheckedOut;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setIsCheckedOut(boolean isCheckedOut) {
        this.isCheckedOut = isCheckedOut;
    }
}
